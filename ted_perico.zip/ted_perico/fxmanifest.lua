fx_version 'bodacious'
game 'gta5'

author 'Tedous'
description 'Cayo Perico by Tedous'

client_scripts {
  'client.lua'
}